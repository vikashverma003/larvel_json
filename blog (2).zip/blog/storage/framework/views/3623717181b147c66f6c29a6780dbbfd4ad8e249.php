<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>HTML Table</h2>

<button type="button" ><a href="/form">Add </a></button>
<table>
  <thead>
  <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Image</th>
    <td>Edit</td>
        <td>Delete</td>
    
  </tr>
</thead>
<tbody>


    <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
    <td><?php echo e($forms->name); ?></td>
    <td><?php echo e($forms->email); ?></td>
    <?php

    $image = json_decode($forms->image);

    ?>


<!-- <td> <img style="height:50px;" src="<?php echo e(asset('New_File/imagess/' . $forms->image)); ?>" /> </td> -->
<?php
if(!empty($image))
{
?>

<?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td> <img style="height:50px;" src="<?php echo e(asset('New_File/imagess/' . $img)); ?>" /> </td>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php
}
else
{

?>
<td> <img style="height:50px;" src="<?php echo e(asset('New_File/imagess/' . $forms->image)); ?>" /> </td>

<?php
}
?>

<td><a href="/edit_form/<?php echo e($forms->id); ?>">edit</a></td>
<td><a href="/delete/<?php echo e($forms->id); ?>">delete</a></td>

     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



 
  </tbody>
  
</table>

</body>
</html>
