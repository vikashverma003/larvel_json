<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Filename extends Model
{
    

protected $fillable = [
        'name', 'gender', 'sex', 'age',
    ];


}
