<!DOCTYPE html>
<html>
<body>

<h2>Forms</h2>

<form action="/data/loginStore" method="post">

	@csrf
  Email:<br>
  <input type="text" name="email" >
  <br>
  Password:<br>
  <input type="password" name="password" >
  <br><br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>
