<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Mail\newEmail;
use Illuminate\Support\Facades\Mail;

use App\jobs\SendEmailJobs;
use Carbon\Carbon;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/jso', 'PagesController@jso');

Route::get('/jso1', 'PagesController@jso1');



Route::get('loginForm', 'TestController@loginForm')->middleware('test');

Route::post('/data/loginStore', 'TestController@loginStore');


Route::get('/admin/logout', function(){
    Session::flush();
    Auth::logout();
    return Redirect::to("/")
      ->with('message', array('type' => 'success', 'text' => 'You have successfully logged out'));
});



// Route::get('sendAnother', function(){


// Mail::send(new newEmail());

// });

Route::get('sendAnother1', 'PagesController@sendMail2');


/* for the markdown email */
Route::get('sendAnother', 'PagesController@sendMail1');
Route::get('send', 'PagesController@sendMail');


/*Now for the jobs */

/* here we are sending the email from the controller or we are using the dispatching from the controller */
Route::get('testing', 'PagesController@testing');


Route::get('sendJobs', function(){

	$jobs = (new SendEmailJobs())
								->delay(Carbon::now()->addSeconds(5));

	dispatch($jobs);

	return "job has been sent";

});




Route::get('/', 'PagesController@index');

Route::get('/about', 'PagesController@about');


Route::get('/services', 'PagesController@services');

Route::resource('posts', 'PostsController');

Route::get('/all', 'PostsController@all');

//Route::match(['get'], '/addPosts', 'PostsController@add');

Route::get('/add', 'PagesController@add');

Route::post('/addPost', 'PagesController@addPost');




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/test1', 'TestController@index')->middleware('test');

Route::get('/check', 'TestSession@check');

Route::post('/checkStore', 'TestSession@checkStore');

// Route::get('/form', 'PagesController@form')->middleware('test:ravi');

// Route::get('/form', 'PagesController@form')->middleware('test:ravi');
Route::get('/form', 'PagesController@form')->middleware('test:admin');

Route::post('/form/store', 'PagesController@addForm');


Route::get('/fetchAll', 'PagesController@fetchAll')->name('fetch');

Route::get('/delete/{id}', 'PagesController@delete');

Route::get('/edit_form/{id}', 'PagesController@edit_form');

Route::post('edit_form/post/{id}', 'PagesController@edit_post');

Route::get('/user_post/{id}', 'PagesController@user_post');





