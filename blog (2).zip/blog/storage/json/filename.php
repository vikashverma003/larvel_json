{  
           "video_title":"Export MySQL data to Excel in PHP - PHP Tutorial"  
      },  
      {  
           "video_title":"Live Table Add Edit Delete using Ajax Jquery in PHP Mysql"  
      },  
      {  
           "video_title":"Make SEO Friendly or Clean Url in PHP using .htaccess"  
      },  
      {  
           "video_title":"How to Add Watertext or Watermark to an Image using PHP GD Library"  
      },  
      {  
           "video_title":"Create Simple Image using PHP"  
      },  
      {  
           "video_title":"How to check Multiple value exists in an Array in PHP"  
      },  
      {  
           "video_title":"How to merge two PHP JSON Array"  
      },  
      {  
           "video_title":"How To Insert Data Using Stored Procedure In Php Mysql"  
      },  
      {  
           "video_title":"How to check Username availability using php, Ajax, Jquery and Mysql"  
      },  
      {  
           "video_title":"Rename uploaded image in php with upload validation"  
      },  
      {  
           "video_title":"How to generate simple random password in php?"  
      },  
      {  
           "video_title":"Auto Refresh Div Content Using jQuery and AJAX"  
      },  
      {  
           "video_title":"Insert Update Delete using Stored Procedure in Mysql and PHP"  
      }  