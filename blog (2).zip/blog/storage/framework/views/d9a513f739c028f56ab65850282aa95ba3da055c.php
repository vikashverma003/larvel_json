<?php $__env->startSection('content'); ?>

<h1>Posts</h1>

<?php if(count($post)>0): ?>

<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="well">

<h3><a href="/posts/<?php echo e($posts->id); ?>"><?php echo e($posts->title); ?></a></h3>

<small>written on <?php echo e($posts->created_at); ?> and written by <?php echo e($posts->user->name); ?></small>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($post->links()); ?>


<?php else: ?>
<p>No post found</p>

<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>