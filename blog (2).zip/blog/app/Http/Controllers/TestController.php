<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\User;
use Hash;

class TestController extends Controller
{
    //

    public function index()

    {


    	//$user = new User->where('id', 1);
$post =User::orderBy('id', 'desc')->take(5)->get();
echo "<pre>";
    	print_r($post);

    }


    	public function loginForm(Request $request)
    	{


//     		$user = User::get();
// echo "<pre>";
//     		print_r($user);

//     		die();



return view('loginForm');




    	}

    	public function loginStore(Request $request)
    	{

    		$email =  $request->email;

    		$enteredPass = $request->password;

    		//echo $enteredPass;
    	
    		$user = User::where('email', $email)->first();

    		if($user)
    		{

    			$pass = $user->password;

    			$name = $user->name;

    			//echo $name;

    			// die();

    			if($enteredPass == $pass)

    			{

    				echo "login created";


    				// for setting/storing the session data
    			  $request->session()->put('user', $name);

    			  // for getting the session data
    			 $sessionContent = $request->session()->get('user');

    				return view('sessionStore')->with('sessionContent', $sessionContent);

    			}
    			else
    			{

    				echo "no login";
    			}


    		}
else
{
            echo "no user found";
}

    	}






}
