<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Mail;
use App\Post;
use App\Form;
use App\User;

use Hash;
// use Validator;

use App\Mail\newEmail;
use App\Mail\SendEmail;
use App\Testing;
use App\jobs\SendEmailJobs;
use Illuminate\Contracts\Queue\ShouldQueue;
use Carbon\Carbon;
use App\Video;

use App\Filename;



// use Illuminate\Support\Facades\Mail;

class PagesController extends Controller
{


// relationship

  public function user_post($id)
  {

    $user = User::find($id);

    // $post = $user->posts;
// $post;

    foreach($user->posts as $pot)
    {

      /* Here we are checking if data is in array format it is then it will loop through all the items */

      if(!is_array(json_decode($pot->title)))
      {
      echo $pot->title ."<br/>";
       }
       else
       {



        foreach(json_decode($pot->title) as $pots)
        {
          echo $pots ."<br/>";

        }
       }

      echo $pot->id ."<br/>";
        echo $pot->body ."<br/>"."<hr/>";
    }

    /*
      



    */




  }

  public function jso(Request $request)
  {

    // $script_name = basename("video.json");
    $string = file_get_contents(basename("video.json"), true); 
      $data = json_decode($string, true); 
      foreach($data as $da)
      {

         $video = new Video;
         $video->video_title=json_encode($da['video_title']);
         $video->save();
      }
    

    /* store in json array */
      /*$c=array();

      foreach($data as $da)
      {


         array_push($c, $da);

      }
    $video = new Video;

    $video->video_title=json_encode($c);
        
        $video->save();*/

        /* store in array format*/
     /*$c=array();

      foreach($data as $da)
      {

        $con = $da['video_title'];

        array_push($c, $con);

        //echo $con;

      }
      $video->video_title=json_encode($c);
        
        $video->save(); */

/*
$data = file_get_contents (basename("video.json"), true);
        $json = json_decode($data, true);
        foreach ($json as $key => $value) {
            if (!is_array($value)) {
                echo $key . '=>' . $value . '<br/>';
            } else {
                foreach ($value as $key => $val) {
                    echo $key . '=>' . $val . '<br/>';
                }
            }
        }
*/


  }

 public function jso1(Request $request)
  {


      // $script_name = basename("video.json");


      $string = file_get_contents(basename("filename.json"), true); 


      $data = json_decode($string, true); 
    

    /* fetch data from json file and store in the database  */

      foreach($data as $da)
      {
        $video = new Filename;

        $video->name=$da['name'];

        $video->gender=$da['gender'];

        $video->sex=$da['sex'];

        $video->age=$da['age'];
        $video->save();


      }
        

  }


  public function testing(Request $request)
  {

      $testing = new Testing;

      $testing->name = "dfdfd";

      $testing->email = "g@gmail.com";

      $testing->country = "aus";

      $testing->save();
      echo "saved";
      
      $user  = User::find(1);

      // SendEmailJobs::dispatch($user);

      $jobs = (new SendEmailJobs($user))
                ->delay(Carbon::now()->addSeconds(5));

      dispatch($jobs);

  }





    public function sendMail(Request $request)
    {

        Mail::send(['text'=>'mail'],['name', 'vikas'], function($message){

            $message->to('vikashverma003@gmail.com', 'to vikash')->subject('test mail');
            //$message->from('vikashverma003@gmail.com', 'vikash');
        });    

    }


 public function sendMail1(Request $request)
    {

      //
        /*Important one*/

       // Mail::send(new newEmail());
      Mail::to('vikashverma003@gmail.com')->send(new newEmail());
    }

     public function sendMail2(Request $request)
    {
       /*Important one*/

       Mail::to('vikashverma003@gmail.com')->send(new SendEmail());

            // Mail::send(new SendEmail());
    }


    public function index()

    {


    	return view('pages.index');
    }

     public function about()

    {


    	return view('pages.about');
    }


     public function services()

    {

    	$data = array(

    		'services'=>'here is services',

    		'title'=> ['weq', 'ere', 'dfdf']

    		);

    	return view('pages.services')->with($data);
    }

        public function add(Request $request)
        {


        return view('posts.add');
        }

        public function addPost(Request $request)
        {
             $validatedData = $request->validate([
        //'title' => 'required',
        'body' => 'required'
        //'image'=>'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
    ]);

            //  $array = array('laptop','earphones','mouse');
            // $data= json_encode($array);

            $post  = new Post;
            // $post->title = $data;
            $title =$request->title;
            foreach($title as $titles)
            {
              $post->title = $titles;
            }

            // $post->title = $request->title;

            // foreach((array)$data as $da)
            // {

            //   $post->title =  $da['key'];

            //   $post->body = $da['value'];


            // }

            $post->body = $request->body;

            $post->user_id = 3;

                if ($request->hasFile('image')) {
                    $profilePic = $request->file('image');
                    $dateFolder = strtotime(date("Y-m-d H:i:s")); 
                    $fileName = $dateFolder."_".$profilePic->getClientOriginalName();
                    $filePath = "uploads/background_image/";
                    $finalPath = storage_path("app/".$filePath);
                    $profilePic = $profilePic->move($finalPath, $fileName);
                    $post->cover_image = $filePath . $fileName;
                }

                // return response()->json($post);

                // die();
                $post->save();

                return redirect('/add');

                echo "success";

        }


        public function form()
        {

            return view('form');
        }


        public function addForm(Request $request)
        {

 //           echo 232;
  $validatedData = $request->validate([
        'name' => 'required',
        'email' => 'required',
       // 'image'=>'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
    ]);

        $form = new Form;

        $form->name = $request->name;


       $form->email = $request->email;
        //$form->password = Hash::make($request->pwd);
       if ($request->hasFile('image')) {

         //$im='';

        // $im = '';

        //  foreach($request->file('image') as $image)
        //     {
        //         $name=$image->getClientOriginalName();
        //         $image->move(public_path().'/New_File/imagess/', $name);

        //         // array_push($im, $name);
        //         $im = $im.' '.$name;
               
        //     }
          

        //     $form->image =  $im;

         $im = array();

         foreach($request->file('image') as $image)
            {
                $name=$image->getClientOriginalName();
                $image->move(public_path().'/New_File/imagess/', $name);

                array_push($im, $name);
                // $im = $im.' '.$name;
               
            }
          

            $form->image =  json_encode($im);


        }

       $form->comments = $request->comment;
       $form->save();

       echo "content saved";
          // return redirect('/fetchAll');
          // return redirect('/fetch');
       return redirect()->route('fetch');





        }


        public function fetchAll(Request $request)
        {

                    $form = Form::all();
                    // echo "<pre>";
                    // print_r($form);

                    return view('all_image')->with('form', $form);

                    




        }



        public function edit_form(Request $request, $id)
        {
            // echo $id;

            $form = Form::where('id', $id);

            return view('edit_form')->with('form', $form);



        }

        public function edit_post(Request $request, $id)
        {
            //echo $id;

           $form = Form::find($id);

           $form->name = $request->name;


          $form->email = $request->email;
           $im = '';
          if($request->hasFile('image'))
          {

           

            foreach($request->file('image') as $images)

            {

                $name = $images->getClientOriginalName();

                $images->move(public_path().'/New_File/imagess/', $name);

                $im = $im.' '.$name;

            }


          }

          $form->image = $im;

          $form->comments = $request->comment;

          $form->save();

          return redirect('/fetchAll');

          


        }


        public function delete(Request $request, $id)
        {
            // echo $id;
            $form = Form::find($id);
            $form->delete();

            echo "deleted";         
                      return redirect('/fetchAll');
   


        }





}
