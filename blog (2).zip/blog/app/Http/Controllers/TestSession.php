<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\User;
use Hash;
use Session;

class TestSession extends Controller
{
    //


    public function check(Request $request)
    {
       return view('test_session');
    }


    public function checkStore(Request $request)
    {

        $data = $request->input('firstname');
        $request->session()->put('da', $data);

        echo $request->session()->get('da');
die();
        return view('welcome')->with('user',   $request->session()->get('da'));
    }

   



}
