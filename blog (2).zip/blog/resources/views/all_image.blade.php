<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>HTML Table</h2>

<button type="button" ><a href="/form">Add </a></button>
<table>
  <thead>
  <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Image</th>
    <td>Edit</td>
        <td>Delete</td>
    
  </tr>
</thead>
<tbody>


    @foreach($form as $forms)
      <tr>
    <td>{{$forms->name}}</td>
    <td>{{$forms->email}}</td>
    <?php

    $image = json_decode($forms->image);

    ?>


<!-- <td> <img style="height:50px;" src="{{ asset('New_File/imagess/' . $forms->image) }}" /> </td> -->
<?php
if(!empty($image))
{
?>

@foreach($image as $img)
<td> <img style="height:50px;" src="{{ asset('New_File/imagess/' . $img) }}" /> </td>

@endforeach

<?php
}
else
{

?>
<td> <img style="height:50px;" src="{{ asset('New_File/imagess/' . $forms->image) }}" /> </td>

<?php
}
?>

<td><a href="/edit_form/{{$forms->id}}">edit</a></td>
<td><a href="/delete/{{$forms->id}}">delete</a></td>

     </tr>
    @endforeach()



 
  </tbody>
  
</table>

</body>
</html>
