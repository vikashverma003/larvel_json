<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Up form</h2>
  <form class="form-horizontal" action="/edit_form/post/<?php echo e($form->id); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

 <div class="form-group">
      <label class="control-label col-sm-2" for="email">Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo e($form->name); ?>">
      </div>
    </div>
        <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e($form->email); ?>">
      </div>
    </div>
    

     <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">file:</label>
      <div class="col-sm-10">          
        <input type="file" class="form-control" id="image"  placeholder="Select file " name="image[]" accept=".png, .jpg, .jpeg" multiple >

        <img  style="width:50px;" src="<?php echo e(asset('New_File/imagess/' . $form->image)); ?>" >
      </div>
    </div>


    <div class="form-group">
      <label for="comment">Comment:</label>
      <textarea class="form-control" rows="5" id="comment" name="comment" value="<?php echo e($form->comments); ?>"></textarea>
    </div>

    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
</div>

</body>
</html>
