<?php

namespace App\Http\Middleware;

use Closure;

//use App\User;

use App\Form;

class test
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $name)
    {



       // $ip = $request->ip();
       //  if($ip == '127.1.0.1')

       //  {
       //      return redirect('/');
       //  }

$form = Form::where('name', 'ravi')->first();

// $form= Form::find(3);

// if($name =$form->name)
// {
//     // 
//     return redirect('/');

// }
    

$form= Form::find(3);

if($name !=$form->role)
{
    // 
    return redirect('/');

}


return $next($request);

     // 
    }
}
