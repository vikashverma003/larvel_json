-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 04, 2019 at 01:29 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lsapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_12_27_122537_create_posts_table', 1),
(4, '2018_12_28_140151_add_users_id_to_posts', 2),
(5, '2018_12_29_172608_add_cover_image_to_posts', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cover_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`, `user_id`, `cover_image`) VALUES
(13, 'dddfd', '<p>dfdf</p>', '2018-12-29 12:22:19', '2018-12-29 12:22:19', 2, '39020884_2135806923110779_4623516518729121792_n_1546105939_png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'john', 'john@gmail.com', NULL, '$2y$10$6NPmKGVzmxY8hKb0UII82.DxO/K7vYEjycgcUJIobAmXHWIu3iY4q', 'mgYIrI62ryLGv6RwJsq6kHAJxtBOfXHn8bNAwQe0bgnhc8aFJtoNfVNWqPsL', '2018-12-28 08:29:22', '2018-12-28 08:29:22'),
(2, 'admin', 'admin@gmail.com', NULL, '$2y$10$pVLwrmrqRXMY4CrVfxTUUebPHTOsRhHiTtDIfBX5LFKaBbvFHMzEy', '7KishHf0U5hRt5fbHlyIrdjBB6xwPsCsBmMyVxyuf2DulGf6rXpncZxSAhjr', '2018-12-28 08:44:21', '2018-12-28 08:44:21'),
(3, 'sam', 'sam@gmail.com', NULL, '$2y$10$2BYyh49KyOfxss3lt7WqDek6Bb2QvzwvD6cbR0eVdbMdxA4f0kREq', '3kXPaaoPFtQtCotTCHqIDZGJJWXJI2ECYrYHML2z6meNogstiCL0UMi9eg1d', '2018-12-28 09:34:51', '2018-12-28 09:34:51'),
(4, 'a', 'a@gmail.com', NULL, '$2y$10$Q22g6eCw0ySv39TyG2rbGODj1gl7mnURScH9dT7gbNGrRoO23mEKW', '3wBu4bEmr5YYnrSpHgVQ28q7yVIXxDsKFbjuI0KM7cdv8SaKGQBDyoXle6hx', '2018-12-29 09:37:35', '2018-12-29 09:37:35'),
(5, 'asd', 'asd@gmail.com', NULL, '$2y$10$V9pu8o8AzLMyApFzOeSM9.MqsuE/z63I9bKIvzhqUja57E3sFYJoG', NULL, '2019-04-14 01:32:14', '2019-04-14 01:32:14'),
(6, 'danny', 'danny@gmail.com', NULL, '$2y$10$Zm10EZeiOy.Itz8wZImUPe3HhVgMg3Y4p6FDs85vb2FOWcfqgz3R.', 'BkJ77RoSGIg80PtpZgxHjdIksUwhQEnzFjoHexKWFtMuj70kbRuZsAwdGOfk', '2019-05-01 13:10:34', '2019-05-01 13:10:34'),
(7, 'sam3', 'sam3@gmail.com', NULL, '$2y$10$h6ym9.09snXi4LP05BxuMe9QwyGvKPbKLLpPcLMuIKnzUZoYN7WUi', NULL, '2019-05-04 07:48:01', '2019-05-04 07:48:01');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
