<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

<form action="/checkStore" method="post">
	<?php echo csrf_field(); ?>
  First name:<br>
  <input type="text" name="firstname" >
  <br>
  
  <br><br>
  <input type="submit" value="Submit">
</form> 


</body>
</html>
